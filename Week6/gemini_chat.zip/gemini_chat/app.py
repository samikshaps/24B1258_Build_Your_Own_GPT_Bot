from flask import Flask, request, jsonify, render_template
import requests

app = Flask(__name__)

API_KEY = "AIzaSyAH9XQQ0Vy7VHGyow9SOlgA4fP7UkbxUvo"  
API_URL = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={API_KEY}"

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    user_input = request.json["message"]
    payload = {
        "contents": [
            {
                "role": "user",
                "parts": [{"text": user_input}]
            }
        ]
    }
    headers = {
        "Content-Type": "application/json"
    }
    response = requests.post(API_URL, headers=headers, json=payload)

    if response.status_code == 200:
        text = response.json()["candidates"][0]["content"]["parts"][0]["text"]

        # Convert Markdown-style bullets to HTML <li>
        bullet_points = ""
        for line in text.splitlines():
            if line.strip().startswith("*"):
                bullet_points += f"<li>{line.strip()[1:].strip()}</li>"
            elif line.strip() != "":
                bullet_points += f"<li>{line.strip()}</li>"

        return jsonify({"response": bullet_points})
    else:
        return jsonify({"error": "API call failed", "details": response.text}), 500

if __name__ == "__main__":
    app.run(debug=True)

